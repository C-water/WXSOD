# MatlabEvaluationTools
The evaluation tool (Matlab version) for saliency maps.

1. Put GTs of your dataset in ./Dataset.
2. Put your saliency maps in ./SalMap.
3. Modify the 'Models' and 'Datasets' in ./Code/main.m, and then run it.
